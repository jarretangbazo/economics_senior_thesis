"""
Interactive .dta file explorer
Launch this with: python explore_dta.py path/to/file.dta
"""

import pandas as pd
import sys

def explore_dta_interactive(filepath):
    """Interactive explorer for .dta files"""
    
    # Load file
    print("Loading file...")
    df = pd.read_stata(filepath, convert_categoricals=False)
    print(f"✓ Loaded {len(df):,} observations, {len(df.columns):,} variables\n")
    
    while True:
        print("\n" + "="*70)
        print("WHAT WOULD YOU LIKE TO DO?")
        print("="*70)
        print("1. List all variables")
        print("2. View first N rows")
        print("3. View specific columns")
        print("4. Get summary statistics")
        print("5. Frequency table for a variable")
        print("6. Search for variables by name")
        print("7. Export to CSV")
        print("8. Exit")
        print("="*70)
        
        choice = input("\nEnter choice (1-8): ").strip()
        
        if choice == '1':
            print(f"\n📋 All {len(df.columns)} variables:")
            for i, col in enumerate(df.columns, 1):
                dtype = df[col].dtype
                non_null = df[col].notna().sum()
                pct = (non_null / len(df)) * 100
                print(f"   {i:3}. {col:40} [{dtype}] {non_null:,}/{len(df):,} ({pct:.1f}% complete)")
        
        elif choice == '2':
            n = input("How many rows? (default 10): ").strip()
            n = int(n) if n else 10
            print(f"\n👀 First {n} rows:")
            print(df.head(n))
        
        elif choice == '3':
            cols = input("Enter column names (comma-separated): ").strip()
            cols = [c.strip() for c in cols.split(',')]
            valid_cols = [c for c in cols if c in df.columns]
            if valid_cols:
                print(f"\n📊 Viewing columns: {', '.join(valid_cols)}")
                print(df[valid_cols].head(20))
            else:
                print("❌ No valid columns found")
        
        elif choice == '4':
            print("\n📈 Summary Statistics:")
            print(df.describe())
        
        elif choice == '5':
            var = input("Enter variable name: ").strip()
            if var in df.columns:
                print(f"\n📊 Frequency table for '{var}':")
                counts = df[var].value_counts().head(20)
                for val, count in counts.items():
                    pct = (count / len(df)) * 100
                    print(f"   {val}: {count:,} ({pct:.1f}%)")
                if df[var].nunique() > 20:
                    print(f"   ... ({df[var].nunique() - 20} more unique values)")
            else:
                print(f"❌ Variable '{var}' not found")
        
        elif choice == '6':
            search = input("Search for (case-insensitive): ").strip().lower()
            matches = [col for col in df.columns if search in col.lower()]
            if matches:
                print(f"\n🔍 Found {len(matches)} matching variables:")
                for col in matches:
                    print(f"   • {col}")
            else:
                print(f"❌ No variables matching '{search}'")
        
        elif choice == '7':
            filename = input("Output filename (e.g., output.csv): ").strip()
            if not filename:
                filename = "output.csv"
            df.to_csv(filename, index=False)
            print(f"✓ Saved to {filename}")
        
        elif choice == '8':
            print("\n👋 Goodbye!")
            break
        
        else:
            print("❌ Invalid choice")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python explore_dta.py path/to/file.dta")
        sys.exit(1)
    
    filepath = sys.argv[1]
    explore_dta_interactive(filepath)
