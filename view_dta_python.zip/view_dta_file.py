"""
Simple script to view Stata .dta files
Usage: python view_dta_file.py path/to/file.dta
"""

import pandas as pd
import sys

def view_dta(filepath):
    """View a Stata .dta file"""
    
    print("="*70)
    print(f"VIEWING: {filepath}")
    print("="*70)
    
    # Load the file
    df = pd.read_stata(filepath, convert_categoricals=False)
    
    print(f"\n📊 Basic Info:")
    print(f"   Observations: {len(df):,}")
    print(f"   Variables: {len(df.columns):,}")
    
    print(f"\n📋 Variables (first 50):")
    for i, col in enumerate(df.columns[:50], 1):
        dtype = df[col].dtype
        non_null = df[col].notna().sum()
        print(f"   {i:3}. {col:30} ({dtype}, {non_null:,} non-null)")
    
    if len(df.columns) > 50:
        print(f"   ... and {len(df.columns) - 50} more variables")
    
    print(f"\n👀 First 10 rows:")
    # Show first 10 rows, first 10 columns
    print(df.iloc[:10, :10].to_string())
    
    print(f"\n💾 To save as CSV:")
    print(f"   df.to_csv('output.csv', index=False)")
    
    print(f"\n🔍 To explore interactively:")
    print(f"   # In Python/IPython:")
    print(f"   df = pd.read_stata('{filepath}', convert_categoricals=False)")
    print(f"   df.head()  # View first rows")
    print(f"   df.describe()  # Summary statistics")
    print(f"   df['variable_name'].value_counts()  # Frequency table")
    
    return df

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python view_dta_file.py path/to/file.dta")
        sys.exit(1)
    
    filepath = sys.argv[1]
    df = view_dta(filepath)
