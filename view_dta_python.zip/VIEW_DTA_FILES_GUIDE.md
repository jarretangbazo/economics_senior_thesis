# How to View .dta (Stata) Files on Mac Without Stata

## ✅ **Option 1: Python (RECOMMENDED - You Already Have This!)**

You already have Python and pandas installed, so this is the easiest option.

### Quick View in Terminal

```bash
# Navigate to directory with .dta file
cd /path/to/your/dhs_data

# Use the viewer script
python view_dta_file.py NGIR4BFL.DTA
```

### Interactive Explorer

```bash
# For more detailed exploration
python explore_dta.py NGIR4BFL.DTA
```

This gives you an interactive menu to:
- List all variables
- View data rows
- Get summary statistics
- Create frequency tables
- Export to CSV

### Quick Python Commands

```python
import pandas as pd

# Load the file
df = pd.read_stata('NGIR4BFL.DTA', convert_categoricals=False)

# Basic info
print(f"Observations: {len(df)}")
print(f"Variables: {len(df.columns)}")

# View first rows
df.head()

# View specific columns
df[['v012', 'v024', 'v106', 'v133']].head(20)

# Summary statistics
df.describe()

# Frequency table
df['v024'].value_counts()

# Export to CSV
df.to_csv('output.csv', index=False)

# Export specific columns
df[['v012', 'v024', 'v106']].to_csv('selected_vars.csv', index=False)
```

---

## 📊 **Option 2: R (Free)**

If you have R installed:

```r
# Install package (once)
install.packages("haven")

# Load and view
library(haven)
df <- read_dta("NGIR4BFL.DTA")

# View in RStudio
View(df)

# Or in console
head(df)
summary(df)

# Export to CSV
write.csv(df, "output.csv", row.names = FALSE)
```

---

## 🌐 **Option 3: Online Converters (Free, No Installation)**

For quick one-off conversions:

1. **ReStore** (https://www.datafileconverter.com/)
   - Upload .dta file
   - Download as CSV or Excel
   - Limit: Usually small files only

2. **Stat-Transfer Online Demo** (limited)
   - May have file size limits

---

## 💰 **Option 4: Stat/Transfer (Commercial - $89+)**

Professional tool for converting between statistical formats:
- Website: https://stattransfer.com/
- Converts .dta ↔ CSV, Excel, SPSS, SAS, etc.
- One-time purchase, works offline
- Good if you'll be doing this frequently

---

## 📱 **Option 5: Jupyter Notebook (Recommended for Exploration)**

If you want a more visual, interactive experience:

```bash
# Install Jupyter if you don't have it
pip install jupyter

# Start Jupyter
jupyter notebook

# In the notebook, create a new cell:
```

```python
import pandas as pd

df = pd.read_stata('NGIR4BFL.DTA', convert_categoricals=False)

# Display
df.head(10)

# Interactive display
df
```

Jupyter gives you:
- Visual table display
- Easy plotting: `df['v012'].hist()`
- Interactive exploration
- Save as HTML for sharing

---

## 🎯 **Quick Comparison**

| Method | Cost | Ease | Best For |
|--------|------|------|----------|
| **Python** | Free | Easy | Regular use, scripting |
| **R** | Free | Easy | If you already use R |
| **Online** | Free | Very Easy | One-off conversions |
| **Stat/Transfer** | $89+ | Very Easy | Professional/frequent use |
| **Jupyter** | Free | Easy | Interactive exploration |

---

## 📝 **For Your DHS Files Specifically**

Since you're working on a research project with multiple DHS files:

**Best workflow:**
1. Use Python scripts for regular processing
2. Use Jupyter for exploration and creating visualizations
3. Export key variables to CSV for sharing or backup

**Example workflow:**

```python
import pandas as pd

# Load
df = pd.read_stata('NGIR4BFL.DTA', convert_categoricals=False)

# Select key education variables
edu_vars = ['caseid', 'v012', 'v024', 'v106', 'v107', 'v133', 
            'v190', 'v025']

# Create subset
df_subset = df[edu_vars]

# Export
df_subset.to_csv('dhs_education_subset.csv', index=False)

# Now you can open CSV in Excel, Numbers, or any spreadsheet app
```

---

## 🎁 **Bonus: Quick Data Dictionary**

To understand variable names:

```python
import pandas as pd

df = pd.read_stata('NGIR4BFL.DTA', convert_categoricals=False)

# Create data dictionary
data_dict = pd.DataFrame({
    'variable': df.columns,
    'type': [df[col].dtype for col in df.columns],
    'non_null': [df[col].notna().sum() for col in df.columns],
    'unique': [df[col].nunique() for col in df.columns]
})

# Save
data_dict.to_csv('dhs_data_dictionary.csv', index=False)
```

This creates a reference file with all variable names, types, and completeness.

---

## 📁 **Files Provided**

1. **view_dta_file.py** - Quick viewer script
2. **explore_dta.py** - Interactive explorer
3. This guide

All scripts work with the `convert_categoricals=False` fix needed for older DHS files.
