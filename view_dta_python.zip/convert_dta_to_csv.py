"""
Simple .dta to CSV converter
Usage: python convert_dta_to_csv.py input.dta [output.csv]
"""

import pandas as pd
import sys
import os

def convert_dta_to_csv(input_file, output_file=None):
    """Convert .dta file to CSV"""
    
    # Determine output filename
    if output_file is None:
        base = os.path.splitext(input_file)[0]
        output_file = f"{base}.csv"
    
    print(f"Converting {input_file} to {output_file}...")
    
    # Load .dta file
    print("  Loading .dta file...", end=" ")
    df = pd.read_stata(input_file, convert_categoricals=False)
    print(f"✓ ({len(df):,} rows, {len(df.columns):,} columns)")
    
    # Save as CSV
    print("  Saving as CSV...", end=" ")
    df.to_csv(output_file, index=False)
    print("✓")
    
    # File size info
    dta_size = os.path.getsize(input_file) / (1024 * 1024)  # MB
    csv_size = os.path.getsize(output_file) / (1024 * 1024)  # MB
    
    print(f"\n✓ Conversion complete!")
    print(f"  Input:  {input_file} ({dta_size:.1f} MB)")
    print(f"  Output: {output_file} ({csv_size:.1f} MB)")
    print(f"\nYou can now open {output_file} in Excel, Numbers, or any spreadsheet app.")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python convert_dta_to_csv.py input.dta [output.csv]")
        print("\nExample:")
        print("  python convert_dta_to_csv.py NGIR4BFL.DTA")
        print("  python convert_dta_to_csv.py NGIR4BFL.DTA my_data.csv")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None
    
    if not os.path.exists(input_file):
        print(f"Error: File not found: {input_file}")
        sys.exit(1)
    
    convert_dta_to_csv(input_file, output_file)
