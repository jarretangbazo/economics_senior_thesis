# DHS Processing Script - Bug Report and Issues

## CRITICAL BUGS 🚨

### 1. **pd.read_stata() Will Fail** - Line 74
**Severity**: CRITICAL - Script will crash

**Problem**: 
The 2003 DHS file (NGIR4BFL.DTA) has duplicate value labels that cause pandas to fail:
```
ValueError: Value labels for column v326 are not unique. 
These cannot be converted to pandas categoricals.
```

**Current Code**:
```python
df = pd.read_stata(filepath)
```

**Fix**:
```python
df = pd.read_stata(filepath, convert_categoricals=False)
```

**Impact**: Without this fix, the script will crash immediately when trying to load any DHS file with duplicate categorical labels (common in older DHS files).

---

### 2. **Duplicate Key in Dictionary** - Lines 78-108
**Severity**: BUG - Results in missing variable

**Problem**:
The `columns_to_keep` dictionary has 'v024' defined twice:
- Line 92: `'v024': 'region'`
- Line 107: `'v024': 'state_code'`

Python dictionaries only keep the last value for duplicate keys, so 'region' is lost.

**Current Code**:
```python
columns_to_keep = {
    # ... other vars ...
    'v024': 'region',  # This gets overwritten!
    'v025': 'urban_rural',
    # ... many lines later ...
    'v024': 'state_code',  # This one wins
    'v023': 'stratification',
}
```

**Fix** (remove the duplicate):
```python
columns_to_keep = {
    # ... other vars ...
    'v024': 'state_code',  # Keep only one
    'v025': 'urban_rural',
    # ... other vars ...
    'v023': 'stratification',
}
```

**Impact**: Currently not causing a crash, but creates confusion and is a code quality issue.

---

## MODERATE ISSUES ⚠️

### 3. **Misleading State Mapping** - Lines 236-264
**Severity**: MODERATE - Misleading variable names

**Problem**:
For the 2003 DHS, v024 represents **geopolitical zones** (6 regions), not individual states (36 states). The script correctly maps these but the variable names are confusing.

**Data Reality**:
```
v024 codes in 2003 DHS:
1: North Central
2: North East  
3: North West
4: South East
5: South South
6: South West
```

These are NOT individual states like "Borno", "Kano", "Lagos", etc.

**Impact**: 
- The `state` variable actually contains regions, not states
- Cannot match to LGA-level ACLED data (LGAs are within states, not regions)
- The analysis will be at the regional level, not state/LGA level

**Fix**: 
Either:
1. Rename variable from `state` to `region` to be accurate
2. Obtain GPS coordinates file to get actual state/LGA locations
3. Use household member data which may have more granular location

---

## DATA VALIDATION ✓

### Files Tested:
- **NGIR4BFL.DTA** (Individual Recode): ✓ 7,620 observations, 3,696 variables
- **NGHR4BFL.DTA** (Household Recode): ✓ 7,225 observations, 2,701 variables

### Variable Availability:
All expected variables are present in the 2003 DHS files:
- ✓ Age variables (v012, v010)
- ✓ Education variables (v106, v107, v133)
- ✓ Geographic variables (v024, v025)
- ✓ Wealth variables (v190, v191)
- ✓ Sample weights (v005)

### Education Data Quality:
From the 2003 DHS:
- Average years of schooling: **5.30 years**
- No education: **39.6%**
- Primary complete (≥6 years): **51.6%**
- Secondary complete (≥12 years): **17.9%**

These numbers are reasonable for Nigeria in 2003.

---

## ADDITIONAL CONCERNS

### 4. **Geographic Matching for Analysis**
**Problem**: 
Your research question involves conflict at the LGA level, but the 2003 DHS only provides regional codes (6 zones), not state/LGA identifiers.

**Options**:
1. **Best**: Request GPS coordinates file from DHS (available for approved projects)
2. **Good**: Use later DHS rounds (2008+) that have better geographic identifiers
3. **Workaround**: Conduct analysis at regional level instead of LGA level

### 5. **Household vs Individual Files**
**Current Status**: Script only processes individual recode (IR) files (women 15-49)

**Note**: The script mentions needing household member data but doesn't actually load the HR files. If you need:
- Men's education data
- Children's school enrollment
- Full household composition

You'll need to add code to process the household recode files.

---

## RECOMMENDED FIXES (Priority Order)

### 1. CRITICAL - Fix pd.read_stata() call
```python
# Line 74 - Add convert_categoricals=False
df = pd.read_stata(filepath, convert_categoricals=False)
```

### 2. CRITICAL - Remove duplicate v024 key
```python
# Lines 78-109 - Remove line 92, keep line 107
columns_to_keep = {
    'caseid': 'case_id',
    # ... other variables ...
    'v024': 'state_code',  # Only define once
    'v025': 'urban_rural',
    # ... continue ...
}
```

### 3. IMPORTANT - Clarify geographic variable naming
```python
# After state mapping (around line 258), add comment:
df['state'] = df['state_code'].map(state_map)
# NOTE: In 2003 DHS, 'state' actually represents geopolitical zones (regions)
# For LGA-level analysis, GPS coordinates file is required
```

---

## TESTING RESULTS

✓ Script logic is sound
✓ All expected variables present
✓ Education calculations work correctly
✓ Age cohort calculations work correctly
✓ Sample restrictions work correctly

**With the two critical fixes above, the script will run successfully.**

However, for your conflict-education research at the LGA level, you'll need to address the geographic matching issue.
